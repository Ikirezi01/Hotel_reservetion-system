<?php
require_once('./partials/header.php');
require_once('./pages/home.php');
require_once('./partials/footer.php');
?>